
  # Сайт о капусте

  This is a code bundle for Сайт о капусте. The original project is available at https://www.figma.com/design/Ml5BVvDhyDIUkELui11YGu/%D0%A1%D0%B0%D0%B9%D1%82-%D0%BE-%D0%BA%D0%B0%D0%BF%D1%83%D1%81%D1%82%D0%B5.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  