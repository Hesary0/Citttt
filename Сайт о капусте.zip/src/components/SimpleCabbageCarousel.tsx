import { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Badge } from "./ui/badge";

interface NutritionalInfo {
  calories: number;
  protein: number;
  carbs: number;
  fiber: number;
  vitaminC: number;
  vitaminK: number;
}

interface CabbageType {
  id: string;
  name: string;
  scientificName: string;
  image: string;
  description: string;
  nutritionalInfo: NutritionalInfo;
  applications: string[];
  storage: {
    freshness: string;
    temperature: string;
    humidity: string;
    duration: string;
  };
  benefits: string[];
}

const cabbageData: CabbageType[] = [
  {
    id: 'white',
    name: 'Белокочанная капуста',
    scientificName: '',
    image: 'https://images.unsplash.com/photo-1583116935756-f66cd999cdbe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aGl0ZSUyMGNhYmJhZ2V8ZW58MXx8fHwxNzU4NzYyMDI4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Самый популярный и распространенный вид капусты с плотными белыми листьями. Богата витаминами и минералами, обладает универсальными кулинарными свойствами.',
    nutritionalInfo: {
      calories: 25,
      protein: 1.3,
      carbs: 6.0,
      fiber: 2.5,
      vitaminC: 36.6,
      vitaminK: 76
    },
    applications: [
      'Квашение и соления',
      'Супы и борщи',
      'Салаты и гарниры',
      'Голубцы и пироги',
      'Тушение и варка'
    ],
    storage: {
      freshness: 'Плотные головки без темных пятен',
      temperature: '0-2°C',
      humidity: '90-95%',
      duration: '2-5 месяцев'
    },
    benefits: [
      'Укрепляет иммунитет',
      'Улучшает пищеварение',
      'Противовоспалительное действие',
      'Поддерживает здоровье сердца',
      'Антиоксидантные свойства'
    ]
  },
  {
    id: 'red',
    name: 'Краснокочанная капуста',
    scientificName: '',
    image: 'https://images.unsplash.com/photo-1651172915092-4389b362b25d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZWQlMjBjYWJiYWdlfGVufDF8fHx8MTc1ODc2MjAyOHww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Красно-фиолетовая капуста с высоким содержанием антоцианов. Обладает более плотной текстурой и ярким цветом, который сохраняется при термообработке.',
    nutritionalInfo: {
      calories: 31,
      protein: 1.4,
      carbs: 7.4,
      fiber: 2.1,
      vitaminC: 57,
      vitaminK: 38
    },
    applications: [
      'Салаты и маринады',
      'Тушение с яблоками',
      'Декоративное оформление блюд',
      'Консервирование',
      'Свежие соки'
    ],
    storage: {
      freshness: 'Яркий цвет без увядших листьев',
      temperature: '0-1°C',
      humidity: '90-95%',
      duration: '3-6 месяцев'
    },
    benefits: [
      'Высокий уровень антиоксидантов',
      'Поддерживает здоровье глаз',
      'Улучшает кровообращение',
      'Противораковые свойства',
      'Укрепляет сосуды'
    ]
  },
  {
    id: 'savoy',
    name: 'Савойская капуста',
    scientificName: '',
    image: 'https://images.unsplash.com/photo-1594282486756-06f49bb34c05?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYXZveSUyMGNhYmJhZ2V8ZW58MXx8fHwxNzU4NzYyMDI4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Капуста с гофрированными, нежными листьями. Обладает более мягким вкусом и деликатной текстурой по сравнению с белокочанной.',
    nutritionalInfo: {
      calories: 27,
      protein: 2.0,
      carbs: 6.1,
      fiber: 3.1,
      vitaminC: 31,
      vitaminK: 69
    },
    applications: [
      'Деликатные салаты',
      'Быстрое обжаривание',
      'Суп-пюре',
      'Начинки для пирогов',
      'Гарниры к мясу'
    ],
    storage: {
      freshness: 'Упругие гофрированные листья',
      temperature: '0-2°C',
      humidity: '95-98%',
      duration: '1-2 месяца'
    },
    benefits: [
      'Легко усваивается',
      'Богата фолиевой кислотой',
      'Поддерживает нервную систему',
      'Улучшает метаболизм',
      'Низкокалорийный продукт'
    ]
  },
  {
    id: 'brussels',
    name: 'Брюссельская капуста',
    scientificName: '',
    image: 'https://images.unsplash.com/photo-1438118907704-7718ee9a191a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicnVzc2VscyUyMHNwcm91dHN8ZW58MXx8fHwxNzU4NzYyMDI5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Миниатюрные кочанчики, растущие на стебле. Обладает концентрированным вкусом и высокой питательной ценностью.',
    nutritionalInfo: {
      calories: 43,
      protein: 3.4,
      carbs: 8.9,
      fiber: 3.8,
      vitaminC: 85,
      vitaminK: 177
    },
    applications: [
      'Запекание с беконом',
      'Обжаривание на сковороде',
      'Гарниры к мясу',
      'Салаты с орехами',
      'Супы и рагу'
    ],
    storage: {
      freshness: 'Плотные зеленые кочанчики',
      temperature: '0-1°C',
      humidity: '90-95%',
      duration: '3-5 недель'
    },
    benefits: [
      'Очень высокое содержание витамина K',
      'Поддерживает здоровье костей',
      'Детоксикация организма',
      'Противовоспалительный эффект',
      'Улучшает свертываемость крови'
    ]
  },
  {
    id: 'cauliflower',
    name: 'Цветная капуста',
    scientificName: '',
    image: 'https://images.unsplash.com/photo-1569737270187-e250e9a02407?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXVsaWZsb3dlciUyMHZlZ2V0YWJsZXxlbnwxfHx8fDE3NTg3NjI0NTN8MA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Белые плотные соцветия с нежным вкусом. Универсальный овощ для различных способов приготовления и диетического питания.',
    nutritionalInfo: {
      calories: 25,
      protein: 1.9,
      carbs: 5.3,
      fiber: 2.0,
      vitaminC: 48.2,
      vitaminK: 15.5
    },
    applications: [
      'Варка и запекание',
      'Пюре и супы-кремы',
      'Жарка в кляре',
      'Салаты и гарниры',
      'Заморозка на зиму'
    ],
    storage: {
      freshness: 'Белые плотные соцветия без пятен',
      temperature: '0-2°C',
      humidity: '90-95%',
      duration: '2-3 недели'
    },
    benefits: [
      'Поддерживает здоровье мозга',
      'Богата холином',
      'Укрепляет иммунитет',
      'Способствует похудению',
      'Антиканцерогенные свойства'
    ]
  },
  {
    id: 'broccoli',
    name: 'Брокколи',
    scientificName: '',
    image: 'https://images.unsplash.com/photo-1685504445355-0e7bdf90d415?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicm9jY29saXxlbnwxfHx8fDE3NTg3NjIwMzB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Зеленые соцветия с высочайшей питательной ценностью. Считается одним из самых полезных овощей для здорового питания.',
    nutritionalInfo: {
      calories: 34,
      protein: 2.8,
      carbs: 7.0,
      fiber: 2.6,
      vitaminC: 89.2,
      vitaminK: 101.6
    },
    applications: [
      'Паровая обработка',
      'Жарка стир-фрай',
      'Супы и пюре',
      'Салаты и закуски',
      'Смузи и соки'
    ],
    storage: {
      freshness: 'Ярко-зеленые плотные головки',
      temperature: '0-2°C',
      humidity: '90-95%',
      duration: '1-2 недели'
    },
    benefits: [
      'Супер-продукт для здоровья',
      'Мощные антиоксиданты',
      'Поддерживает детоксикацию',
      'Улучшает зрение',
      'Защищает от рака'
    ]
  },
  {
    id: 'kohlrabi',
    name: 'Кольраби',
    scientificName: '',
    image: 'https://images.unsplash.com/photo-1623490439625-758205dc3219?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb2hscmFiaXxlbnwxfHx8fDE3NTg3NjIwMjl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Стеблеплод с нежной текстурой и сладковатым вкусом. Напоминает репу, но относится к семейству капустных.',
    nutritionalInfo: {
      calories: 27,
      protein: 1.7,
      carbs: 6.2,
      fiber: 3.6,
      vitaminC: 62,
      vitaminK: 0.1
    },
    applications: [
      'Сырые салаты',
      'Тушение и варка',
      'Маринование',
      'Начинки для пирогов',
      'Супы и рагу'
    ],
    storage: {
      freshness: 'Твердые клубни без мягких пятен',
      temperature: '0-2°C',
      humidity: '90-95%',
      duration: '2-3 месяца'
    },
    benefits: [
      'Отличный источник клетчатки',
      'Поддерживает пищеварение',
      'Укрепляет иммунитет',
      'Низкокалорийный продукт',
      'Богата калием'
    ]
  }
];

export function SimpleCabbageCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % cabbageData.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + cabbageData.length) % cabbageData.length);
  };

  const currentCabbage = cabbageData[currentIndex];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-secondary/10 p-4">
      {/* Заголовок */}
      <div className="text-center py-12">
        <h1 className="text-5xl mb-4">
          Виды Капусты
        </h1>
      </div>

      {/* Основной контент */}
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-8 items-center">
          {/* Изображение */}
          <div className="relative">
            <div className="aspect-square max-w-lg mx-auto">
              <img 
                src={currentCabbage.image}
                alt={currentCabbage.name}
                className="w-full h-full object-cover rounded-3xl shadow-2xl"
                onError={(e) => {
                  e.currentTarget.src = 'https://images.unsplash.com/photo-1566842600175-97dca489844f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXVsaWZsb3dlcnxlbnwxfHx8fDE3NTg3NjIwMjl8MA&ixlib=rb-4.1.0&q=80&w=1080';
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-3xl" />
            </div>
          </div>

          {/* Информация */}
          <div className="space-y-6">
            <div className="space-y-4">
              <h2 className="text-4xl">
                {currentCabbage.name}
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                {currentCabbage.description}
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              {/* Пищевая ценность */}
              <Card>
                <CardHeader className="pb-3">
                  <h3>Пищевая ценность</h3>
                  <p className="text-xs text-muted-foreground">на 100г продукта</p>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Калории</span>
                    <span>{currentCabbage.nutritionalInfo.calories} ккал</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Белки</span>
                    <span>{currentCabbage.nutritionalInfo.protein}г</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Углеводы</span>
                    <span>{currentCabbage.nutritionalInfo.carbs}г</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Клетчатка</span>
                    <span>{currentCabbage.nutritionalInfo.fiber}г</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Витамин C</span>
                    <span>{currentCabbage.nutritionalInfo.vitaminC}мг</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Витамин K</span>
                    <span>{currentCabbage.nutritionalInfo.vitaminK}мкг</span>
                  </div>
                </CardContent>
              </Card>

              {/* Применение */}
              <Card>
                <CardHeader className="pb-3">
                  <h3>Применение</h3>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {currentCabbage.applications.map((app, index) => (
                      <li key={index} className="text-sm flex items-start gap-2">
                        <span className="text-primary mt-1">•</span>
                        <span>{app}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              {/* Хранение */}
              <Card>
                <CardHeader className="pb-3">
                  <h3>Хранение</h3>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="text-sm">
                    <span className="text-muted-foreground">Свежесть:</span>
                    <p>{currentCabbage.storage.freshness}</p>
                  </div>
                  <div className="text-sm">
                    <span className="text-muted-foreground">Температура:</span>
                    <p>{currentCabbage.storage.temperature}</p>
                  </div>
                  <div className="text-sm">
                    <span className="text-muted-foreground">Влажность:</span>
                    <p>{currentCabbage.storage.humidity}</p>
                  </div>
                  <div className="text-sm">
                    <span className="text-muted-foreground">Срок:</span>
                    <p>{currentCabbage.storage.duration}</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Полезные свойства */}
            <Card>
              <CardHeader>
                <h3>Полезные свойства</h3>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {currentCabbage.benefits.map((benefit, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {benefit}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Навигация */}
        <div className="flex justify-center items-center gap-4 mt-12">
          <Button
            variant="outline"
            size="icon"
            onClick={prevSlide}
            className="rounded-full"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>

          <div className="flex gap-2">
            {cabbageData.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  index === currentIndex 
                    ? 'bg-primary scale-125' 
                    : 'bg-muted-foreground/30 hover:bg-muted-foreground/50'
                }`}
              />
            ))}
          </div>

          <Button
            variant="outline"
            size="icon"
            onClick={nextSlide}
            className="rounded-full"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>

        {/* Прогресс бар */}
        <div className="w-full max-w-md mx-auto mt-8 h-2 bg-muted rounded-full overflow-hidden">
          <div
            className="h-full bg-primary transition-all duration-500 ease-out"
            style={{ width: `${((currentIndex + 1) / cabbageData.length) * 100}%` }}
          />
        </div>
      </div>
    </div>
  );
}