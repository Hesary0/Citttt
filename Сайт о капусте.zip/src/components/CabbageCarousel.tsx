import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from "./ui/button";
import { CabbageSlide } from './CabbageSlide';

interface NutritionalInfo {
  calories: number;
  protein: number;
  carbs: number;
  fiber: number;
  vitaminC: number;
  vitaminK: number;
}

interface CabbageType {
  id: string;
  name: string;
  scientificName: string;
  image: string;
  description: string;
  nutritionalInfo: NutritionalInfo;
  applications: string[];
  storage: {
    freshness: string;
    temperature: string;
    humidity: string;
    duration: string;
  };
  benefits: string[];
}

const cabbageData: CabbageType[] = [
  {
    id: 'white',
    name: 'Белокочанная капуста',
    scientificName: 'Brassica oleracea var. capitata',
    image: 'https://images.unsplash.com/photo-1583116935756-f66cd999cdbe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aGl0ZSUyMGNhYmJhZ2V8ZW58MXx8fHwxNzU4NzYyMDI4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Самый популярный и распространенный вид капусты с плотными белыми листьями. Богата витаминами и минералами, обладает универсальными кулинарными свойствами.',
    nutritionalInfo: {
      calories: 25,
      protein: 1.3,
      carbs: 6.0,
      fiber: 2.5,
      vitaminC: 36.6,
      vitaminK: 76
    },
    applications: [
      'Квашение и соления',
      'Супы и борщи',
      'Салаты и гарниры',
      'Голубцы и пироги',
      'Тушение и варка'
    ],
    storage: {
      freshness: 'Плотные головки без темных пятен',
      temperature: '0-2°C',
      humidity: '90-95%',
      duration: '2-5 месяцев'
    },
    benefits: [
      'Укрепляет иммунитет',
      'Улучшает пищеварение',
      'Противовоспалительное действие',
      'Поддерживает здоровье сердца',
      'Антиоксидантные свойства'
    ]
  },
  {
    id: 'red',
    name: 'Краснокочанная капуста',
    scientificName: 'Brassica oleracea var. capitata f. rubra',
    image: 'https://images.unsplash.com/photo-1651172915092-4389b362b25d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZWQlMjBjYWJiYWdlfGVufDF8fHx8MTc1ODc2MjAyOHww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Красно-фиолетовая капуста с высоким содержанием антоцианов. Обладает более плотной текстурой и ярким цветом, который сохраняется при термообработке.',
    nutritionalInfo: {
      calories: 31,
      protein: 1.4,
      carbs: 7.4,
      fiber: 2.1,
      vitaminC: 57,
      vitaminK: 38
    },
    applications: [
      'Салаты и маринады',
      'Тушение с яблоками',
      'Декоративное оформление блюд',
      'Консервирование',
      'Свежие соки'
    ],
    storage: {
      freshness: 'Яркий цвет без увядших листьев',
      temperature: '0-1°C',
      humidity: '90-95%',
      duration: '3-6 месяцев'
    },
    benefits: [
      'Высокий уровень антиоксидантов',
      'Поддерживает здоровье глаз',
      'Улучшает кровообращение',
      'Противораковые свойства',
      'Укрепляет сосуды'
    ]
  },
  {
    id: 'savoy',
    name: 'Савойская капуста',
    scientificName: 'Brassica oleracea var. sabauda',
    image: 'https://images.unsplash.com/photo-1594282486756-06f49bb34c05?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYXZveSUyMGNhYmJhZ2V8ZW58MXx8fHwxNzU4NzYyMDI4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Капуста с гофрированными, нежными листьями. Обладает более мягким вкусом и деликатной текстурой по сравнению с белокочанной.',
    nutritionalInfo: {
      calories: 27,
      protein: 2.0,
      carbs: 6.1,
      fiber: 3.1,
      vitaminC: 31,
      vitaminK: 69
    },
    applications: [
      'Деликатные салаты',
      'Быстрое обжаривание',
      'Суп-пюре',
      'Начинки для пирогов',
      'Гарниры к мясу'
    ],
    storage: {
      freshness: 'Упругие гофрированные листья',
      temperature: '0-2°C',
      humidity: '95-98%',
      duration: '1-2 месяца'
    },
    benefits: [
      'Легко усваивается',
      'Богата фолиевой кислотой',
      'Поддерживает нервную систему',
      'Улучшает метаболизм',
      'Низкокалорийный продукт'
    ]
  },
  {
    id: 'brussels',
    name: 'Брюссельская капуста',
    scientificName: 'Brassica oleracea var. gemmifera',
    image: 'https://images.unsplash.com/photo-1438118907704-7718ee9a191a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicnVzc2VscyUyMHNwcm91dHN8ZW58MXx8fHwxNzU4NzYyMDI5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Миниатюрные кочанчики, растущие на стебле. Обладает концентрированным вкусом и высокой питательной ценностью.',
    nutritionalInfo: {
      calories: 43,
      protein: 3.4,
      carbs: 8.9,
      fiber: 3.8,
      vitaminC: 85,
      vitaminK: 177
    },
    applications: [
      'Запекание с беконом',
      'Обжаривание на сковороде',
      'Гарниры к мясу',
      'Салаты с орехами',
      'Супы и рагу'
    ],
    storage: {
      freshness: 'Плотные зеленые кочанчики',
      temperature: '0-1°C',
      humidity: '90-95%',
      duration: '3-5 недель'
    },
    benefits: [
      'Очень высокое содержание витамина K',
      'Поддерживает здоровье костей',
      'Детоксикация организма',
      'Противовоспалительный эффект',
      'Улучшает свертываемость крови'
    ]
  },
  {
    id: 'cauliflower',
    name: 'Цветная капуста',
    scientificName: 'Brassica oleracea var. botrytis',
    image: 'https://images.unsplash.com/photo-1566842600175-97dca489844f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXVsaWZsb3dlcnxlbnwxfHx8fDE3NTg3NjIwMjl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Белые плотные соцветия с нежным вкусом. Универсальный овощ для различных способов приготовления и диетического питания.',
    nutritionalInfo: {
      calories: 25,
      protein: 1.9,
      carbs: 5.3,
      fiber: 2.0,
      vitaminC: 48.2,
      vitaminK: 15.5
    },
    applications: [
      'Варка и запекание',
      'Пюре и супы-кремы',
      'Жарка в кляре',
      'Салаты и гарниры',
      'Заморозка на зиму'
    ],
    storage: {
      freshness: 'Белые плотные соцветия без пятен',
      temperature: '0-2°C',
      humidity: '90-95%',
      duration: '2-3 недели'
    },
    benefits: [
      'Поддерживает здоровье мозга',
      'Богата холином',
      'Укрепляет иммунитет',
      'Способствует похудению',
      'Антиканцерогенные свойства'
    ]
  },
  {
    id: 'broccoli',
    name: 'Брокколи',
    scientificName: 'Brassica oleracea var. italica',
    image: 'https://images.unsplash.com/photo-1685504445355-0e7bdf90d415?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicm9jY29saXxlbnwxfHx8fDE3NTg3NjIwMzB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Зеленые соцветия с высочайшей питательной ценностью. Считается одним из самых полезных овощей для здорового питания.',
    nutritionalInfo: {
      calories: 34,
      protein: 2.8,
      carbs: 7.0,
      fiber: 2.6,
      vitaminC: 89.2,
      vitaminK: 101.6
    },
    applications: [
      'Паровая обработка',
      'Жарка стир-фрай',
      'Супы и пюре',
      'Салаты и закуски',
      'Смузи и соки'
    ],
    storage: {
      freshness: 'Ярко-зеленые плотные головки',
      temperature: '0-2°C',
      humidity: '90-95%',
      duration: '1-2 недели'
    },
    benefits: [
      'Супер-продукт для здоровья',
      'Мощные антиоксиданты',
      'Поддерживает детоксикацию',
      'Улучшает зрение',
      'Защищает от рака'
    ]
  },
  {
    id: 'kohlrabi',
    name: 'Кольраби',
    scientificName: 'Brassica oleracea var. gongylodes',
    image: 'https://images.unsplash.com/photo-1623490439625-758205dc3219?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb2hscmFiaXxlbnwxfHx8fDE3NTg3NjIwMjl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Стеблеплод с нежной текстурой и сладковатым вкусом. Напоминает репу, но относится к семейству капустных.',
    nutritionalInfo: {
      calories: 27,
      protein: 1.7,
      carbs: 6.2,
      fiber: 3.6,
      vitaminC: 62,
      vitaminK: 0.1
    },
    applications: [
      'Сырые салаты',
      'Тушение и варка',
      'Маринование',
      'Начинки для пирогов',
      'Супы и рагу'
    ],
    storage: {
      freshness: 'Твердые клубни без мягких пятен',
      temperature: '0-2°C',
      humidity: '90-95%',
      duration: '2-3 месяца'
    },
    benefits: [
      'Отличный источник клетчатки',
      'Поддерживает пищеварение',
      'Укрепляет иммунитет',
      'Низкокалорийный продукт',
      'Богата калием'
    ]
  }
];

export function CabbageCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);

  const nextSlide = () => {
    setDirection(1);
    setCurrentIndex((prev) => (prev + 1) % cabbageData.length);
  };

  const prevSlide = () => {
    setDirection(-1);
    setCurrentIndex((prev) => (prev - 1 + cabbageData.length) % cabbageData.length);
  };

  useEffect(() => {
    const timer = setInterval(nextSlide, 10000); // Автопрокрутка каждые 10 секунд
    return () => clearInterval(timer);
  }, []);

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0
    })
  };

  return (
    <div className="relative w-full min-h-screen bg-gradient-to-br from-background to-secondary/10">
      {/* Заголовок */}
      <motion.div 
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-center py-12"
      >
        <h1 className="text-6xl font-bold bg-gradient-to-r from-primary via-primary/80 to-primary/60 bg-clip-text text-transparent mb-4">
          Мир Капусты
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Откройте для себя удивительное разнообразие видов капусты, их пищевую ценность и полезные свойства
        </p>
      </motion.div>

      {/* Слайды */}
      <div className="relative min-h-[600px] overflow-hidden">
        <AnimatePresence initial={false} custom={direction}>
          <motion.div
            key={currentIndex}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{
              x: { type: "spring", stiffness: 300, damping: 30 },
              opacity: { duration: 0.2 }
            }}
            className="absolute inset-0 w-full"
          >
            <CabbageSlide 
              cabbage={cabbageData[currentIndex]} 
              isActive={true}
            />
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Навигация */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex items-center gap-4">
        <Button
          variant="outline"
          size="icon"
          onClick={prevSlide}
          className="rounded-full bg-background/80 backdrop-blur-sm hover:bg-background/90"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>

        <div className="flex gap-2">
          {cabbageData.map((_, index) => (
            <button
              key={index}
              onClick={() => {
                setDirection(index > currentIndex ? 1 : -1);
                setCurrentIndex(index);
              }}
              className={`w-3 h-3 rounded-full transition-all duration-300 ${
                index === currentIndex 
                  ? 'bg-primary scale-125' 
                  : 'bg-muted-foreground/30 hover:bg-muted-foreground/50'
              }`}
            />
          ))}
        </div>

        <Button
          variant="outline"
          size="icon"
          onClick={nextSlide}
          className="rounded-full bg-background/80 backdrop-blur-sm hover:bg-background/90"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      {/* Прогресс бар */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-muted">
        <motion.div
          className="h-full bg-gradient-to-r from-primary to-primary/70"
          initial={{ width: "0%" }}
          animate={{ width: `${((currentIndex + 1) / cabbageData.length) * 100}%` }}
          transition={{ duration: 0.5 }}
        />
      </div>
    </div>
  );
}