import { motion } from 'motion/react';
import { Card, CardContent, CardHeader } from "./ui/card";
import { Badge } from "./ui/badge";


interface NutritionalInfo {
  calories: number;
  protein: number;
  carbs: number;
  fiber: number;
  vitaminC: number;
  vitaminK: number;
}

interface CabbageType {
  id: string;
  name: string;
  scientificName: string;
  image: string;
  description: string;
  nutritionalInfo: NutritionalInfo;
  applications: string[];
  storage: {
    freshness: string;
    temperature: string;
    humidity: string;
    duration: string;
  };
  benefits: string[];
}

interface CabbageSlideProps {
  cabbage: CabbageType;
  isActive: boolean;
}

export function CabbageSlide({ cabbage, isActive }: CabbageSlideProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ 
        opacity: isActive ? 1 : 0.8, 
        y: isActive ? 0 : 20,
        scale: isActive ? 1 : 0.95
      }}
      transition={{ 
        duration: 0.8, 
        ease: [0.25, 0.46, 0.45, 0.94] 
      }}
      className="w-full max-w-7xl mx-auto px-4"
    >
      <div className="grid lg:grid-cols-2 gap-8 items-center min-h-[500px] py-8">
        {/* Изображение */}
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative"
        >
          <div className="relative aspect-square max-w-lg mx-auto">
            <img 
              src={cabbage.image}
              alt={cabbage.name}
              className="w-full h-full object-cover rounded-3xl shadow-2xl"
              onError={(e) => {
                e.currentTarget.src = 'https://images.unsplash.com/photo-1566842600175-97dca489844f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXVsaWZsb3dlcnxlbnwxfHx8fDE3NTg3NjIwMjl8MA&ixlib=rb-4.1.0&q=80&w=1080';
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-3xl" />
          </div>
        </motion.div>

        {/* Информация */}
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="space-y-6"
        >
          <div className="space-y-4">
            <Badge variant="secondary" className="text-sm px-4 py-2">
              {cabbage.scientificName}
            </Badge>
            <h1 className="text-5xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
              {cabbage.name}
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed">
              {cabbage.description}
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Пищевая ценность */}
            <Card className="border-none shadow-lg bg-gradient-to-br from-background to-secondary/5">
              <CardHeader className="pb-3">
                <h3 className="font-semibold text-primary">Пищевая ценность</h3>
                <p className="text-xs text-muted-foreground">на 100г продукта</p>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Калории</span>
                  <span className="font-medium">{cabbage.nutritionalInfo.calories} ккал</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Белки</span>
                  <span className="font-medium">{cabbage.nutritionalInfo.protein}г</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Углеводы</span>
                  <span className="font-medium">{cabbage.nutritionalInfo.carbs}г</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Клетчатка</span>
                  <span className="font-medium">{cabbage.nutritionalInfo.fiber}г</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Витамин C</span>
                  <span className="font-medium">{cabbage.nutritionalInfo.vitaminC}мг</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Витамин K</span>
                  <span className="font-medium">{cabbage.nutritionalInfo.vitaminK}мкг</span>
                </div>
              </CardContent>
            </Card>

            {/* Применение */}
            <Card className="border-none shadow-lg bg-gradient-to-br from-background to-accent/5">
              <CardHeader className="pb-3">
                <h3 className="font-semibold text-primary">Применение</h3>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {cabbage.applications.map((app, index) => (
                    <li key={index} className="text-sm flex items-start gap-2">
                      <span className="text-primary mt-1">•</span>
                      <span>{app}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Хранение */}
            <Card className="border-none shadow-lg bg-gradient-to-br from-background to-muted/5">
              <CardHeader className="pb-3">
                <h3 className="font-semibold text-primary">Хранение</h3>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="text-sm">
                  <span className="text-muted-foreground">Свежесть:</span>
                  <p className="font-medium">{cabbage.storage.freshness}</p>
                </div>
                <div className="text-sm">
                  <span className="text-muted-foreground">Температура:</span>
                  <p className="font-medium">{cabbage.storage.temperature}</p>
                </div>
                <div className="text-sm">
                  <span className="text-muted-foreground">Влажность:</span>
                  <p className="font-medium">{cabbage.storage.humidity}</p>
                </div>
                <div className="text-sm">
                  <span className="text-muted-foreground">Срок:</span>
                  <p className="font-medium">{cabbage.storage.duration}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Полезные свойства */}
          <Card className="border-none shadow-lg bg-gradient-to-r from-primary/5 to-secondary/5">
            <CardHeader>
              <h3 className="font-semibold text-primary">Полезные свойства</h3>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {cabbage.benefits.map((benefit, index) => (
                  <Badge key={index} variant="outline" className="text-xs">
                    {benefit}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </motion.div>
  );
}